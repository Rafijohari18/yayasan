<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProfilAlumni extends Model
{
    protected $table = 'profil_alumni';
    protected $guarded = [];

    
}

@extends('layouts.frontend')
@section('title','Profil - Yayasan Nurul Ilmi')
@section('content')

@endsection
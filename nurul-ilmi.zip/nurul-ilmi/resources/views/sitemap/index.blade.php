<?php echo '<?xml version="1.0" encoding="UTF-8"?>'; ?>

<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">    
    <sitemap>
        <loc>https://radarpulsa.org</loc>
        <lastmod>2020-12-03</lastmod>
    </sitemap>
    <sitemap>
        <loc>https://radarpulsa.org/format/transaksi</loc>
        <lastmod>2020-12-03</lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.8</priority>
    </sitemap>
    <sitemap>
        <loc>https://radarpulsa.org/cara/pendaftaran</loc>
        <lastmod>2020-12-03</lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.8</priority>
    </sitemap>
    <sitemap>
        <loc>https://radarpulsa.org/kontak</loc>
        <lastmod>2020-12-03</lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.8</priority>
    </sitemap>
    <sitemap>
        <loc>https://radarpulsa.org/produk</loc>
        <lastmod>2020-12-03</lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.8</priority>
    </sitemap>

</sitemapindex>


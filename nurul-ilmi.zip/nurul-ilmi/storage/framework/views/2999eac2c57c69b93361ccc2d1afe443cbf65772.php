

<?php $__env->startSection('title', $data['title']); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('asset/temp_backend/libs/summernote/summernote-bs4.min.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content -->
<div class="container-fluid flex-grow-1 container-p-y">

    <h4 class="font-weight-bold py-3 mb-4">
      <span class="text-muted font-weight-light">Alumni  /</span> Edit <span class="text-muted"></span>
    </h4>

    <div class="card mb-4">
      <h6 class="card-header">
        <i class="fas fa-plus"></i> Edit Alumni 
      </h6>
      <div class="card-body">
      
      <form enctype="multipart/form-data" action="<?php echo e(route('alumni.update', ['id' => $data['alumni']['id']])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
          
            
      
        
          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Nama</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($data['alumni']['nama']); ?>" id="nama" name="nama" required>
             
            </div>
          </div>

          
          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Jenis Kelamin</label>
            <div class="col-sm-10">
            <select required class="form-control selectpicker show-tick <?php $__errorArgs = ['jk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jk" data-style="btn-default">      
                <option value="L" <?php echo e($data['alumni']['jk'] == "L" ? 'selected' : ''); ?>> Laki-Laki</option>
                <option value="P" <?php echo e($data['alumni']['jk'] == "P" ? 'selected' : ''); ?>> Perempuan</option>
            </select>  
                    
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Foto</label>
            <div class="col-sm-10">
              <input type="file" class="form-control filestyle <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="foto" name="foto">
              <input type="hidden" name="foto_dulu" value="<?php echo e($data['alumni']['foto']); ?>">
              
            </div>
          </div>



          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Tempat Lahir</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($data['alumni']['tempat_lahir']); ?>" required id="tempat_lahir" name="tempat_lahir">
             
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Tanggal Lahir</label>
            <div class="col-sm-10">
              <input type="date" class="form-control <?php $__errorArgs = ['tgl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="tgl_lahir" value="<?php echo e($data['alumni']['tgl_lahir']); ?>" name="tgl_lahir">
            </div>
          </div>


          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">No Handphone</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($data['alumni']['no_hp']); ?>" id="no_hp" name="no_hp" required>
             
            </div>
          </div>


        
         <div class="form-group row">
                <label class="col-form-label col-sm-2 text-sm-left">Alamat</label>
                <div class="col-sm-10">
                    <textarea class="form-control" name="alamat"><?php echo e($data['alumni']['alamat']); ?></textarea>
                </div>
         </div> 


         <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Masuk Tahun</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['masuk_tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($data['alumni']['masuk_tahun']); ?>" id="masuk_tahun" name="masuk_tahun" required>
             
            </div>
          </div>


          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Tamat Tahun</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['tamat_tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($data['alumni']['tamat_tahun']); ?>" id="tamat_tahun" name="tamat_tahun" required>
             
            </div>
          </div>


         <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Tingkat Sekolah / Pekerjaan Saat Ini</label>
            <div class="col-sm-10">
              <input type="text"  value="<?php echo e($data['alumni']['sekolah_ke']); ?>" class="form-control <?php $__errorArgs = ['sekolah_ke'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="sekolah_ke" name="sekolah_ke" required>
             
            </div>
          </div>





   
        
      



       

          <div class="form-group row">
            <div class="col-sm-10 ml-sm-auto">
              <button type="submit" class="btn btn-primary">Simpan</button>
              
            </div>
          </div>
        </form>
      </div>
    </div>

</div>
<!-- / Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsfoot'); ?>

 
<script src="<?php echo e(asset('asset/temp_backend/js/admin.js')); ?>"></script>

<script src="<?php echo e(asset('asset/temp_backend/libs/admin-resources/bootstrap-filestyle/bootstrap-filestyle.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/libs/bootstrap-maxlength/bootstrap-maxlength.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/js/pages/form-advanced.init.js')); ?>"></script>


<script src="<?php echo e(asset('asset/temp_backend/libs/tinymce/tinymce.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/libs/summernote/summernote-bs4.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/js/pages/form-editor.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nurul-ilmi\resources\views\backend\alumni\edit.blade.php ENDPATH**/ ?>
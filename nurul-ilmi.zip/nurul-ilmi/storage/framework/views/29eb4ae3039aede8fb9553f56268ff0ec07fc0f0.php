<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount($name, $params)->html();
} elseif ($_instance->childHasBeenRendered('GnjysI0')) {
    $componentId = $_instance->getRenderedChildComponentId('GnjysI0');
    $componentTag = $_instance->getRenderedChildComponentTagName('GnjysI0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GnjysI0');
} else {
    $response = \Livewire\Livewire::mount($name, $params);
    $html = $response->html();
    $_instance->logRenderedChild('GnjysI0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php /**PATH C:\laragon\www\sd-nurul-ilmi\vendor\livewire\livewire\src\views\mount-component.blade.php ENDPATH**/ ?>
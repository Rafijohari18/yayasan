

<?php $__env->startSection('title', $data['title']); ?>

<?php $__env->startSection('content'); ?>

 <!-- start page title -->
 <div class="row align-items-center">
    <div class="col-sm-6">
        <div class="page-title-box">
            <h4 class="font-size-18">Data Profil Alumni</h4>
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="javascript: void(0);">Data Master</a></li>
                <li class="breadcrumb-item active">Data Profil Alumni</li>
            </ol>
        </div>
    </div>

    <div class="col-sm-6">
        <div class="float-right d-none d-md-block">
                <a href="<?php echo e(route('profil.alumni.create')); ?>" class="btn btn-primary dropdown-toggle waves-effect waves-light">
                    <i class="mdi mdi-plus"></i> Tambah
                </a>

                <a class="btn btn-success text-white" data-toggle="modal" data-target="#importExcel">
                    <i class="mdi mdi-file-excel-outline"></i> Import
                </a>
        </div>
    </div>
</div>     
                        <!-- end page title -->
<div class="row">
    <div class="col-12">
        <div class="card">
            
            <div class="card-body">
            
                <h4 class="card-title">Data Profil Alumni</h4>
               
               
                <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                    <thead>
                    <tr>
                      <th>No</th>
                      <th>Nama Lengkap</th>
                      <th>Foto</th>
                      <th>Angkatan</th>
                      <th>Pekerjaan</th>
                      <th>Aksi</th>
                    </tr>
                    </thead>


                    <tbody>
                    <?php $__currentLoopData = $data['alumni']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($loop->iteration); ?></td>
                      <td><?php echo e($item->nama); ?></td>
                      <td>
                        <img src="<?php echo e(asset($item->foto)); ?>" class="img-thumbnail" style="width:80px;height:auto;"></td>
                      <td><?php echo e($item->angkatan); ?></td>
                      <td><?php echo e($item->pekerjaan); ?></td>
                
                     <td>
                
                            <a href="<?php echo e(route('profil.alumni.edit', ['id' => $item['id']])); ?>" class="btn icon-btn btn-sm btn-info" data-toggle="tooltip" data-original-title="click to edit alumni">
                                <i class="ion ion-md-create"></i>
                            </a>
                            
                            <a href="<?php echo e(route('profil.alumni.destroy', ['id' => $item['id']])); ?>" class="btn icon-btn btn-sm btn-danger delete" onclick="return confirm('Anda Yakin ?')" data-toggle="tooltip" data-original-title="click to delete alumni"><i class="ion ion-md-trash"></i>
                                
                            </a>
                   
                        </td>
                    </tr>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    
                    </tbody>
                </table>

            </div>
        </div>
    </div> <!-- end col -->
</div> <!-- end row -->

<div class="modal fade" id="importExcel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form method="POST" action="<?php echo e(route('profil.alumni.import')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Import Excel</h5>
            </div>
            <div class="modal-body">

                <p>"Fitur Profil Alumni memungkinkan untuk Anda mengupload banyak data dalam bentuk Excel (.xlsx), silakan download FORMAT excel berikut untuk Anda sesuaikan".
                <br><a href="<?php echo e(Route('profil.alumni.download')); ?>" class="badge badge-primary mt-2">Download Disini</a>
                <hr>

            <div class="form-group">
                <label>Pilih file excel</label>
                <br>
                <input class="form-control" name="import_file" type="file">
            </div>

            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Import</button>
            </div>
        </div>
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('jsbody'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nurul-ilmi\resources\views/backend/profilalumni/index.blade.php ENDPATH**/ ?>
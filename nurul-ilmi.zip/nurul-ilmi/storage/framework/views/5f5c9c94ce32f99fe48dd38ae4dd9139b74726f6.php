<ul class="metismenu list-unstyled" id="side-menu">
        

        <li>
            <a href="<?php echo e(route('home')); ?>" class="waves-effect">
                <i class="ti-home"></i>
                <span>Dashboard</span>
            </a>
        </li>

        

        <li class="menu-title">MODUL</li>
            <li>
                <a href="javascript: void(0);" class="has-arrow waves-effect">
                    <i class="ti-archive"></i>
                    <span> Data Master </span>
                </a>
                <ul class="sub-menu" aria-expanded="false">
                
                    <li><a href="<?php echo e(route('pages.index')); ?>">Halaman</a></li>
                    <li><a href="<?php echo e(route('category.content.index')); ?>">Konten</a></li>
                    <li><a href="<?php echo e(route('slider.index')); ?>">Slider Konten</a></li>
                    <li><a href="<?php echo e(route('profil.alumni.index')); ?>">Profil Alumni</a></li>

                    <!-- <li><a href="<?php echo e(route('dosen.index')); ?>">Data Dosen</a></li> -->
                    <!-- <li><a href="<?php echo e(route('product.index')); ?>">Produk</a></li> -->
                                        
                </ul>
                
            </li>

            <li>
                <a href="javascript: void(0);" class="has-arrow waves-effect">
                    <i class="ti-gallery"></i>
                    <span> Gallery </span>
                </a>
                
                <ul class="sub-menu" aria-expanded="false">
                
                    <li><a href="<?php echo e(route('gallery.album.index')); ?>">Photo</a></li>
                    <li><a href="<?php echo e(route('gallery.playlist.index')); ?>">Video</a></li>
                                    
                </ul>

               
            </li>

            <li>
                <a href="javascript: void(0);" class="has-arrow waves-effect">
                    <i class="ti-user"></i>
                    <span> Pengelolaan User </span>
                </a>
                
                <ul class="sub-menu" aria-expanded="false">
                    <!-- <li><a href="<?php echo e(route('siswa.index')); ?>">Data Siswa</a></li>
                    <li><a href="<?php echo e(route('alumni.index')); ?>">Data Alumni</a></li>
                    <li><a href="<?php echo e(route('guru.index')); ?>">Data Guru</a></li> -->
                    
                    <li><a href="<?php echo e(route('users.index')); ?>">Data User</a></li>               
                </ul>
            </li>

            <li>
                <a href="<?php echo e(route('web-config')); ?>" class="waves-effect">
                <i class="ti-settings"></i>
                    <span>Konfigurasi Web</span>
                </a>
                
            </li>
    </ul><?php /**PATH C:\laragon\www\nurul-ilmi\resources\views\backend\sidebar.blade.php ENDPATH**/ ?>
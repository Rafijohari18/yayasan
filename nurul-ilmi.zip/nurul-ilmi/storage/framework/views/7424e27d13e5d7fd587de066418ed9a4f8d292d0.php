
<?php $__env->startSection('title', $data['content']->title); ?>
<?php $__env->startSection('content'); ?>

<aside id="colorlib-hero">
    <div class="flexslider">
        <ul class="slides">
            <li style="background-image: url(<?php echo e(asset($background->value)); ?>);">
                <div class="overlay"></div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-6 col-sm-12 col-md-offset-3 col-xs-12 slider-text">
                            <div class="slider-text-inner text-center">
                                <h1><?php echo e($data['content']->title); ?></h1>
                                <h2 class="breadcrumbs"><span><a href="<?php echo e(url('/')); ?>">Home</a></span> | <span><?php echo e($data['content']->title); ?></span></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</aside>

<div class="colorlib-classes">
			<div class="container">
				<div class="row">
					<div class="col-md-8">
						<div class="row row-pb-lg">
							<div class="col-md-12 animate-box">
								<div class="classes class-single">
									<div class="classes-img" style="background-image: url(<?php echo e(asset($data['content']->cover)); ?>);">
									</div>
									<div class="desc desc2">
										<h3><a href="#"><?php echo e($data['content']->title); ?></a></h3>
										    <?php echo $data['content']->content; ?>

									</div>
								</div>
							</div>
						</div>
					
						
					</div>

					<div class="col-md-4 animate-box">
						<div class="sidebar">
							
							<div class="side">
								<h3 class="sidebar-heading">Latest Posts</h3>
								<?php $__currentLoopData = $data['content_news']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content_news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="f-blog">
									<a href="<?php echo e(route('berita.detail',['slug' => $content_news->slug])); ?>" class="blog-img" style="background-image: url(<?php echo e(asset($content_news->cover)); ?>);">
									</a>
									<div class="desc">
										<p class="admin"><span><?php echo e(Carbon\Carbon::parse($content_news->created_at)->translatedFormat('d F Y')); ?></span></p>
										<h2><a href="<?php echo e(route('berita.detail',['slug' => $content_news->slug])); ?>"><?php echo e($content_news->title); ?></a></h2>
										
									</div>
								</div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
							</div>
						
						</div>
					</div>
				</div>
			</div>
		</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nurul-ilmi\resources\views\frontend\detail_berita.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', $data['title']); ?>

<?php $__env->startSection('content'); ?>
<!-- Content -->
<div class="container-fluid flex-grow-1 container-p-y">

    <h4 class="font-weight-bold py-3 mb-4">
      <span class="text-muted font-weight-light">Kategori Konten / <?php echo e(ucfirst(Request::segment(2))); ?> /</span> <?php echo e($data['title']); ?> <span class="text-muted"></span>
    </h4>

    <div class="card mb-4">
      <h6 class="card-header">
        <i class="fas fa-<?php echo e($data['type'] == 'create' ? 'plus' : 'edit'); ?>"></i> <?php echo e($data['type'] == 'create' ? 'Tambah Kategori Konten' : 'Edit Kategori Konten'); ?> 
      </h6>
      <div class="card-body">
        <form action="<?php echo e($data['type'] == 'create' ? route('category.content.store') : route('category.content.update', ['id' => $data['content']['id']])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php if($data['type'] == 'edit'): ?>
            <?php echo method_field('PUT'); ?>
            <?php endif; ?>
          
          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Nama</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" value="<?php echo e($data['type'] == 'create' ? old('name') : old('name', $data['content']['name'])); ?>" placeholder="enter name...">
              <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Slug</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="slug" name="slug" value="<?php echo e($data['type'] == 'create' ? old('slug') : old('slug', $data['content']['slug'])); ?>" placeholder="enter slug...">
              <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <div class="form-group row">
            <div class="col-sm-10 ml-sm-auto">
              <button type="submit" class="btn btn-primary"><?php echo e($data['type'] == 'create' ? 'Simpan' : 'Simpan Perubahan'); ?></button>
              
            </div>
          </div>
        </form>
      </div>
    </div>

</div>
<!-- / Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsfoot'); ?>
<script>
  $('#name').bind("change keyup",function(){
        $("#slug").val($(this).val().toLowerCase().replace(/\s+/g, "-").replace(/\/+/g, "-"));
    });


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nurul-ilmi\resources\views/backend/content/form.blade.php ENDPATH**/ ?>
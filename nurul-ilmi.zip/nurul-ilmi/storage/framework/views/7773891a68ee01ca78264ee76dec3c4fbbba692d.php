

<?php $__env->startSection('title', $data['title']); ?>

<?php $__env->startSection('content'); ?>
<!-- Content -->
<div class="container-fluid flex-grow-1 container-p-y">

    <h4 class="font-weight-bold py-3 mb-4">
      <span class="text-muted font-weight-light">Pengelolaan User / <?php echo e(ucfirst(Request::segment(2))); ?> /</span> <?php echo e($data['title']); ?> <span class="text-muted"><?php echo e($data['type'] == 'edit' ? '#'.$data['users']['id'] : ''); ?></span>
    </h4>

    <div class="card mb-4">
      <h6 class="card-header">
        <i class="fas fa-<?php echo e($data['type'] == 'create' ? 'plus' : 'edit'); ?>"></i> <?php echo e($data['type'] == 'create' ? 'Create User' : 'User / '.$data['users']['name'].''); ?> 
      </h6>
      <div class="card-body">
        <form action="<?php echo e($data['type'] == 'create' ? route('users.store') : route('users.update', ['id' => $data['users']['id']])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php if($data['type'] == 'edit'): ?>
            <?php echo method_field('PUT'); ?>
            <?php endif; ?>
          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Name</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e($data['type'] == 'create' ? old('name') : old('name', $data['users']['name'])); ?>" placeholder="enter name...">
              <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>


        

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Roles</label>
            <div class="col-sm-10">
                <select class="form-control selectpicker show-tick <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="level" name="level" data-style="btn-default">
                    <option value="">Select Role</option>
                    <option value="1" <?php echo e($data['type'] == 'create' ? old('level') == 1 ? 'selected' : ''  : old('level', $data['users']['level']) == 1 ? 'selected' : ''); ?>>Admin</option>
                    <option value="2" <?php echo e($data['type'] == 'create' ? old('level') == 2 ? 'selected' : ''  : old('level', $data['users']['level']) == 2 ? 'selected' : ''); ?>>Penulis</option>
                </select>  
                <?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div style="color:red;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
          </div>

          
         
          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Email</label>
            <div class="col-sm-10">
              <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e($data['type'] == 'create' ? old('email') : old('email', $data['users']['email'])); ?>" placeholder="enter email...">
              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>



         
         
         

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Password</label>
            <div class="col-sm-10">
              <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" value="<?php echo e(old('password')); ?>" placeholder="enter password...">
              <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Password Confirmation</label>
            <div class="col-sm-10">
              <input type="password" class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" placeholder="enter password confirmation...">
              <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="form-group row">
            <div class="col-sm-10 ml-sm-auto">
              <button type="submit" class="btn btn-primary"><?php echo e($data['type'] == 'create' ? 'Simpan' : 'Simpan Perubahan'); ?></button>
              <a href="<?php echo e(route('users.index')); ?>" class="btn btn-default">Cancel</a>
            </div>
          </div>
        </form>
      </div>
    </div>

</div>
<!-- / Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsfoot'); ?>
<script>
  


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nurul-ilmi\resources\views\backend\users\form.blade.php ENDPATH**/ ?>
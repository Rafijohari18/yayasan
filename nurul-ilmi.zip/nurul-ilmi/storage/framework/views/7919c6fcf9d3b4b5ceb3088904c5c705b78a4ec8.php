

<?php $__env->startSection('title', $data['title']); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid flex-grow-1 container-p-y">

    <h4 class="font-weight-bold py-3 mb-4">
        <span class="text-muted font-weight-light">Module / Playlist / </span><?php echo e($data['title']); ?> <span class="text-muted"><?php echo e(isset($data['playlist']) ? '#'.$data['playlist']['id'] : ''); ?></span>
    </h4>

    <a href="<?php echo e(route('gallery.playlist.index', ['playlistId' => $data['playlist']['id']])); ?>" class="btn btn-sm btn-secondary"><i class="ion ion-ios-arrow-back"></i> Back</a><br><br>

    <!-- Filters -->
    <div class="form-group row">
        <div class="col-sm-2">
            <button class="btn btn-success" data-toggle="modal" data-target="#m_create">
                <i class="fas fa-plus"></i> Create
            </button>
        </div>
    </div>
    <!-- / Filters -->
      
    <!-- Lightbox template -->
    <div class="row drag">
        <?php $__currentLoopData = $data['video']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            if ($item['file'] != '' && $item['youtube_id'] == '') {
                $bg = asset('userfile/default/playlist.jpg');
                $type = 'Video';
            } elseif ($item['file'] == '' && $item['youtube_id'] != '') {
                $bg = 'https://i.ytimg.com/vi/'.$item['youtube_id'].'/mqdefault.jpg';
                $type = 'Youtube Video';
            } else {
                $bg = asset('userfile/default/no-image.jpg');
                $type = 'Extension not detected';
            }
        ?>
        <div class="col-sm-6 col-xl-4" id="<?php echo e($item['id']); ?>" style="cursor: move;">
        <div class="card mb-4">
            <div class="w-100">
            <div class="card-img-top d-block ui-rect-60 ui-bg-cover" style="background-image: url(<?php echo e($bg); ?>);">
                <div class="d-flex justify-content-between align-items-end ui-rect-content p-3">
                <div class="flex-shrink-1">
                    
                </div>
                <div class="text-big">
                    <div class="badge badge-dark font-weight-bold"><?php echo e($type); ?></div>
                </div>
                </div>
            </div>
            </div>
            <div class="card-body">
            <h5 class="mb-3"><a href="#" class="text-body">
                <?php if($item['title'] != ''): ?>
                    <?php echo $item['title']; ?>

                <?php else: ?>
                    <i>"No Title"</i>
                <?php endif; ?>
            </a></h5>
            <p class="text-muted mb-3">
                <?php if($item['description'] != ''): ?>
                    <?php echo $item['description']; ?>

                <?php else: ?>
                    <i>"No Description"</i>
                <?php endif; ?>
            </p>
            <div class="media">
                <div class="media-body">
                <button type="button" class="btn icon-btn btn-sm btn-primary" data-toggle="modal" data-target="#m_edit<?php echo e($item['id']); ?>">
                    <i class="ion ion-md-create text-white"></i>
                </button>
                <a href="javascript:void(0);" class="btn icon-btn btn-sm btn-danger delete" data-toggle="tooltip" data-original-title="click to delete">
                    <i class="ion ion-md-trash text-white"></i>
                    <form action="<?php echo e(route('gallery.playlist.destroy.video', ['id' => $item['id']])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>                                            
                    </form>
                </a>
              
                </div>
                <div class="text-muted small">
                    <i class="ion ion-md-time text-primary"></i>
                    <span><?php echo e($item['created_at']->diffForHumans()); ?></span>
                </div>
            </div>
            </div>
        </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <?php echo e($data['video']->links()); ?>

    
</div>


<div class="modal fade" id="m_create">
    <div class="modal-dialog">
    <form class="modal-content" action="<?php echo e(route('gallery.playlist.store.video', ['playlistId' => $data['playlist']['id']])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="modal-header">
        <h5 class="modal-title">
            Create
            <span class="font-weight-light">Media</span>
        </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">×</button>
        </div>
        <div class="modal-body">
        <div class="form-group row" style="margin-bottom:0;"> 
       
            <div class="form-group col mb-12">
            <label class="col-form-label">From Youtube </label>
            <br>
            <label class="switcher"> 
                <input type="checkbox" id="switch1" switch="none" name="from_yt" value="1"/>
                    <label for="switch1" data-on-label="On" data-off-label="Off"></label>                
            </label>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col mb-12" id="file">
            <label class="form-label">Upload Video</label>
            <input type="file" class="form-control <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="file" value="<?php echo e(old('file')); ?>" placeholder="Enter file...">
            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col mb-12" id="youtube">
            <label class="form-label">Youtube ID</label>
            <input type="text" class="form-control <?php $__errorArgs = ['youtube_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="youtube_id" value="<?php echo e(old('youtube_id')); ?>" placeholder="Enter youtube_id...">
            <?php $__errorArgs = ['youtube_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col mb-12">
                <label class="form-label">Title</label>
                <input type="text" class="form-control" name="title" value="<?php echo e(old('title')); ?>" placeholder="Enter title...">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group col mb-12">
            <label class="form-label">Description</label>
            <textarea type="text" class="form-control" name="description" placeholder="Enter description..."><?php echo e(old('description')); ?></textarea>
            </div>
        </div>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
        </div>
    </form>
    </div>
</div>

<?php $__currentLoopData = $data['video']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="m_edit<?php echo e($modal['id']); ?>">
    <div class="modal-dialog">
      <form class="modal-content" action="<?php echo e(route('gallery.playlist.update.video', ['id' => $modal['id']])); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
        <div class="modal-header">
          <h5 class="modal-title">
            Edit
            <span class="font-weight-light">video</span>
          </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">×</button>
        </div>
        <div class="modal-body">
          <div class="form-row">
            <div class="form-group col mb-12">
              <label class="form-label">Title</label>
              <input type="text" class="form-control" name="title" value="<?php echo e(old('title', $modal['title'])); ?>" placeholder="Enter title...">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col mb-12">
                <label class="form-label">Description</label>
                <textarea type="text" class="form-control" name="description" value="" placeholder="Enter description..."><?php echo e(old('description', $modal['description'])); ?></textarea>
              </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save</button>
        </div>
      </form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/temp_backend/dropzone/dropzone.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('asset/temp_backend/dropzone/basic.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsfoot'); ?>
<script src="<?php echo e(asset('asset/temp_backend/jquery-ui.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('asset/temp_backend/dropzone/dropzone.min.js')); ?>"></script>

<script src="<?php echo e(asset('asset/temp_backend/js/ui_modals.js')); ?>"></script>
<script type="text/javascript">
$(document).ready(function(){

    $('#youtube').hide();
    $('.switcher').change(function(){
        $('#youtube').toggle('slow');
        $('#youtube').prop('required',true);
        $('#file').toggle('slow');
    });
});
</script>
<script>
    $('.delete').click(function(e)
    {
        e.preventDefault();
        var url = $(this).attr('href');
        Swal.fire({
        title: 'Are you sure delete this video ?',
        text: "You won't be able to revert this!",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
        if (result.value) {
            $(this).find('form').submit();
        }
        })
    });

  
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nurul-ilmi\resources\views\backend\gallery\playlist\video.blade.php ENDPATH**/ ?>
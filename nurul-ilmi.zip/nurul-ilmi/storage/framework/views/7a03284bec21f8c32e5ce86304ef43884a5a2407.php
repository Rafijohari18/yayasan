

<?php $__env->startSection('title', $data['title']); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('asset/temp_backend/libs/summernote/summernote-bs4.min.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content -->
<div class="container-fluid flex-grow-1 container-p-y">

    <h4 class="font-weight-bold py-3 mb-4">
      <span class="text-muted font-weight-light">Profil Alumni  /</span> Tambah <span class="text-muted"></span>
    </h4>

    <div class="card mb-4">
      <h6 class="card-header">
        <i class="fas fa-plus"></i> Tambah Profil Alumni 
      </h6>
      <div class="card-body">
        <form enctype="multipart/form-data" action="<?php echo e(route('profil.alumni.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Nama</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama" name="nama" required>
             
            </div>
          </div>


          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Foto</label>
            <div class="col-sm-10">
              <input type="file" class="form-control filestyle <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="foto" name="foto">
              
            </div>
          </div>



          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Pekerjaan</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['pekerjaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="pekerjaan" name="pekerjaan">
             
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Angkatan</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['angkatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="angkatan" name="angkatan">
            </div>
          </div>



         <div class="form-group row">
                <label class="col-form-label col-sm-2 text-sm-left">Alamat</label>
                <div class="col-sm-10">
                    <textarea class="form-control" name="alamat" required></textarea>
                </div>
         </div> 



         <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Moto Hidup</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['moto_hidup'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="moto_hidup" name="moto_hidup">
            </div>
          </div>


      

         <div class="form-group row">
                <label class="col-form-label col-sm-2 text-sm-left">Pesan dan Kesan</label>
                <div class="col-sm-10">
                    <textarea class="form-control" name="pesan_kesan" required></textarea>
                </div>
         </div> 

       

          <div class="form-group row">
            <div class="col-sm-10 ml-sm-auto">
              <button type="submit" class="btn btn-primary">Simpan</button>
              
            </div>
          </div>
        </form>
      </div>
    </div>

</div>
<!-- / Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsfoot'); ?>

 
<script src="<?php echo e(asset('asset/temp_backend/js/admin.js')); ?>"></script>

<script src="<?php echo e(asset('asset/temp_backend/libs/admin-resources/bootstrap-filestyle/bootstrap-filestyle.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/libs/bootstrap-maxlength/bootstrap-maxlength.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/js/pages/form-advanced.init.js')); ?>"></script>


<script src="<?php echo e(asset('asset/temp_backend/libs/tinymce/tinymce.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/libs/summernote/summernote-bs4.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/js/pages/form-editor.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nurul-ilmi\resources\views\backend\profilalumni\create.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', $data['title']); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('asset/temp_backend/css/file-manager.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid flex-grow-1 container-p-y">

    <h4 class="font-weight-bold py-3 mb-4">
        <span class="text-muted font-weight-light">Module / Page / </span><?php echo e($data['title']); ?> <span class="text-muted"><?php echo e(isset($data['page']) ? '#'.$data['page']['id'] : ''); ?></span>
    </h4>

    <a href="<?php echo e(route('pages.index')); ?>" class="btn btn-sm btn-secondary"><i class="ion ion-ios-arrow-back"></i> Back</a><br><br>

    <!-- Filters -->
    <div class="ui-bordered px-4 pt-4 mb-4">
        <form enctype="multipart/form-data" action="<?php echo e(route('pages.media.store', ['pageId' => $data['page']['id']])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <div class="col-sm-5">
                    <div class="input-group">
                        <input type="file" class="filestyle form-control <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  placeholder="No File Selected" name="file" value="<?php echo e(old('file')); ?>">
                        
                        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="text-danger small mt-1">Allowed : <strong>JPG, JPEG, PNG, SVG, MP4, 3GP, MKV, PDF, DOC, DOCX, XLS, PPTX</strong></div>
                   
                </div>
                <div class="col-sm-5">
                    <input type="text" class="form-control" placeholder="Judul" name="title" value="<?php echo e(old('title')); ?>" required>
                </div>
                
                <div class="col-sm-2">
                    <button type="submit" class="btn btn-primary">Add</button>
                </div>
            </div>
        </form>
    </div>
    <!-- / Filters -->
      
    <!-- list -->
    <div class="container-m-nx container-m-ny bg-lightest mb-3">

        <ol class="breadcrumb text-big container-p-x py-3 m-0">
            
        </ol>

        <hr class="m-0">

        <div class="file-manager-actions container-p-x py-2">
          <div>
            
          </div>
          <div>
            <div class="btn-group btn-group-toggle" data-toggle="buttons">
              <label class="btn btn-default icon-btn md-btn-flat active">
                <input type="radio" name="file-manager-view" value="file-manager-col-view" checked> <span class="ion ion-md-apps"></span>
              </label>
              <label class="btn btn-default icon-btn md-btn-flat">
                <input type="radio" name="file-manager-view" value="file-manager-row-view"> <span class="ion ion-md-menu"></span>
              </label>
            </div>
          </div>
        </div>

        <hr class="m-0">
    </div>
    <div class="file-manager-container file-manager-col-view">

        <div class="file-manager-row-header">
            <div class="file-item-name pb-2">Filename</div>
            
        </div>
        <div class="row drag">
            <?php $__currentLoopData = $data['media']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="file-item">
                <div class="file-item-icon file-item-level-up fas fa-level-up-alt text-secondary"></div>
                <a href="javascript:void(0)" class="file-item-name">
                  ..
                </a>
              </div>

              <div class="file-item">
                <div class="file-item-select-bg bg-primary"></div>
                <label class="file-item-checkbox custom-control custom-checkbox">
                  <input type="checkbox" class="custom-control-input">
                  <span class="custom-control-label"></span>
                </label>
                <div class="file-item-icon far fa-folder text-secondary"></div>
                <a href="javascript:void(0)" class="file-item-name">
                  <?php echo e($item->title); ?>

                </a>
                <div class="file-item-changed"></div>
                <div class="file-item-actions btn-group">
                  <button type="button" class="btn btn-default btn-sm rounded-pill icon-btn borderless md-btn-flat hide-arrow dropdown-toggle" data-toggle="dropdown"><i class="ion ion-ios-more"></i></button>
                  <div class="dropdown-menu dropdown-menu-right">
                  
                    <a class="dropdown-item delete" href="<?php echo e(route('pages.media.destroy', ['id' => $item['id']])); ?>" onclick="return confirm('Anda Yakin ?')"  data-toggle="tooltip" data-original-title="click to delete">
                        <i class="ion ion-md-trash text-danger"></i> Hapus
                        
                    </a>
                  </div>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    
    <?php echo e($data['media']->links()); ?>


</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsfoot'); ?>

  
 
<script src="<?php echo e(asset('asset/temp_backend/libs/admin-resources/bootstrap-filestyle/bootstrap-filestyle.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/libs/bootstrap-maxlength/bootstrap-maxlength.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/js/pages/form-advanced.init.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/js/pages/pages_file-manager.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nurul-ilmi\resources\views\backend\pages\media.blade.php ENDPATH**/ ?>
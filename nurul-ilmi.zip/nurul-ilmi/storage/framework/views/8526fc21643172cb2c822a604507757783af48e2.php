

<?php $__env->startSection('title', 'Album - '.$data['title']); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid flex-grow-1 container-p-y">

    <h4 class="font-weight-bold py-3 mb-4">
      <span class="text-muted font-weight-light">Modul / Album /</span> <?php echo e($data['title']); ?> <span class="text-muted"><?php echo e((isset($data['album'])) ? '#'.$data['album']['id'] : ''); ?></span>
    </h4>

    <a href="<?php echo e(route('gallery.album.index')); ?>" class="btn btn-sm btn-secondary"><i class="ion ion-ios-arrow-back"></i> Back</a><br><br>

    <form action="<?php echo e((isset($data['album'])) ? route('gallery.album.update', ['id' => $data['album']['id']]) : route('gallery.album.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php if(isset($data['album'])): ?>
        <?php echo method_field('PUT'); ?>
        <?php endif; ?>
    
        <div class="nav-tabs-top">
          <ul class="nav nav-tabs">
            
              <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#def">Default</a>
              </li>
          </ul>
          <div class="tab-content">
            <div class="tab-pane fade show active" id="def">
      
              <div class="card-body pb-2">
                <div class="form-group row">
                  <label class="col-form-label col-sm-2 text-sm-left">Nama</strong></label>
                  <div class="col-sm-10">
                  <input type="text" class="form-control <?php $__errorArgs = ['name_def'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name_def" value="<?php echo (isset($data['album']))?old('name_def',$data['album']->name):old('name_def'); ?>" placeholder="Enter name...">
                  <?php $__errorArgs = ['name_def'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="invalid-feedback"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="form-group row">
                    <label class="col-form-label col-sm-2 text-sm-left">Deskripsi</strong></label>
                    <div class="col-sm-10">
                    <textarea type="text" class="form-control" name="description_def" placeholder="Enter description..."><?php echo (isset($data['album']))?old('description_def',$data['album']->description):old('description_def'); ?></textarea>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-form-label col-sm-2 text-sm-left">Banner</label>
                    <div class="col-sm-10">
                        <div class="input-group">
                        <input type="file" class="form-control" id="image1" aria-label="Image" aria-describedby="button-image" placeholder="No File Selected" name="banner_img" value="<?php echo e(isset($data['album']) ? old('banner_img', $data['album']['banner']) : old('banner_img')); ?>">
                        
                        <?php if(isset($data['album'])): ?>
                        <input type="hidden" name="cover_lama" value="<?php echo e($data['album']['banner']); ?>">
                        <?php endif; ?>
                        </div>
                        
                        
                    </div>
                  </div>
              </div>
      
            </div>
      
          
          </div>
        </div>
      
        <div class="text-right mt-3">
          <button type="submit" class="btn btn-primary"><?php echo e((isset($data['album'])) ? 'Save changes' : 'Save'); ?></button>&nbsp;
          <button type="button" class="btn btn-default">Cancel</button>
        </div>
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('vendor/file-manager/css/file-manager.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsbody'); ?>
<script src="<?php echo e(asset('vendor/file-manager/js/file-manager.js')); ?>"></script>


<script>
  document.addEventListener("DOMContentLoaded", function() {
  
      document.getElementById('button-image').addEventListener('click', (event) => {
          event.preventDefault();
  
          inputId = 'image1';
  
          window.open('/file-manager/fm-button', 'fm', 'width=1400,height=800');
      });
  
  });
  
  // input
  let inputId = '';
  
  // set file link
  function fmSetLink($url) {
      document.getElementById(inputId).value = $url;
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nurul-ilmi\resources\views\backend\gallery\album\form.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', $data['title']); ?>
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('asset/temp_backend/libs/summernote/summernote-bs4.min.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content -->
<div class="container-fluid flex-grow-1 container-p-y">

    <h4 class="font-weight-bold py-3 mb-4">
      <span class="text-muted font-weight-light">Data Master / Pages /</span> <?php echo e($data['title']); ?> <span class="text-muted"><?php echo e(isset($data['page']) ? '#'.$data['page']['id'] : ''); ?></span>
    </h4>

    <div class="card mb-4">
      
      <div class="card-body">
        <form action="<?php echo e(isset($data['page']) ? route('pages.update', ['id' => $data['page']['id']]) : route('pages.store', 'parent='.request()->get('parent'))); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php if(isset($data['page'])): ?>
            <?php echo method_field('PUT'); ?>
            <?php endif; ?>

            <?php if(isset($data['page'])): ?>
              <input type="hidden" name="id_def" value="<?php echo e($data['page']->getFieldLang()->id); ?>">
            <?php endif; ?>

          <div class="form-group row">
            <label class="col-form-label col-sm-1 text-sm-left">Judul</label>
            <div class="col-sm-10">
              <input type="text" class="form-control gen_slug <?php $__errorArgs = ['title_def'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" lang="id" name="title_def" value="<?php echo isset($data['page'])?old('title_def',$data['page']->getFieldLang()->title):old('title_def'); ?>">
              <?php $__errorArgs = ['title_def'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>


          <div class="form-group row">
                <label class="col-form-label col-sm-1 text-sm-left">Slug</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control slug_spot <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" lang="id" name="slug" maxlength="50" value="<?php echo e(isset($data['page']) ? old('slug', $data['page']['slug']) : old('slug')); ?>" placeholder="slug...">
                    <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-group row">
                <label class="col-form-label col-sm-1 text-sm-left">Content</label>
                <div class="col-sm-10">
                    <textarea class="form-control summernote" name="content_def"><?php echo isset($data['page']) ? old('content_def', $data['page']->getFieldLang()->content) : old('content_def'); ?></textarea>
                </div>
            </div>

          <div class="form-group row">
            <div class="col-sm-10 ml-sm-auto">
              <button type="submit" class="btn btn-primary"><?php echo e(isset($data['page']) ? 'Save changes' : 'Save'); ?></button>
              <a href="<?php echo e(route('pages.index')); ?>" class="btn btn-default">Cancel</a>
            </div>
          </div>
        </form>
      </div>
    </div>

</div>
<!-- / Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsfoot'); ?>
    <script src="<?php echo e(asset('asset/temp_backend/js/admin.js')); ?>"></script>

    <script src="<?php echo e(asset('asset/temp_backend/libs/tinymce/tinymce.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/temp_backend/libs/summernote/summernote-bs4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/temp_backend/js/pages/form-editor.init.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nurul-ilmi\resources\views\backend\pages\form.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title','Profil - Yayasan Nurul Ilmi'); ?>
<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nurul-ilmi\resources\views\frontend\profil.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', $data['title']); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('asset/temp_backend/libs/summernote/summernote-bs4.min.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content -->
<div class="container-fluid flex-grow-1 container-p-y">

    <h4 class="font-weight-bold py-3 mb-4">
      <span class="text-muted font-weight-light">Dosen  /</span> Edit <span class="text-muted"></span>
    </h4>

    <div class="card mb-4">
      <h6 class="card-header">
        <i class="fas fa-<?php echo e($data['type'] == 'create' ? 'plus' : 'edit'); ?>"></i> <?php echo e($data['type'] == 'create' ? 'Tambah Dosen' : 'Edit Dosen'); ?> 
      </h6>
      <div class="card-body">
        <form enctype="multipart/form-data" action="<?php echo e($data['type'] == 'create' ? route('dosen.store') : route('dosen.update', ['id' => $data['dosen']['id']] )); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php if($data['type'] == 'edit'): ?>
            <?php echo method_field('PUT'); ?>
            <?php endif; ?>
          
          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">NIP</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nip" name="nip" value="<?php echo e($data['type'] == 'create' ? old('nip') : old('nip', $data['dosen']['nip'])); ?>" placeholder="enter nip...">
              <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">NIDN</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['nidn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nidn" name="nidn" value="<?php echo e($data['type'] == 'create' ? old('nidn') : old('nidn', $data['dosen']['nidn'])); ?>" placeholder="enter nidn...">
              <?php $__errorArgs = ['nidn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Nama</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama" name="nama" value="<?php echo e($data['type'] == 'create' ? old('nama') : old('nama', $data['dosen']['nama'])); ?>" placeholder="enter nama...">
              <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Foto</label>
            <div class="col-sm-10">
              <input type="file" class="form-control filestyle <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="foto" name="foto" value="<?php echo e($data['type'] == 'create' ? old('foto') : old('foto', $data['dosen']['foto'])); ?>" placeholder="enter foto...">
              <?php if( $data['type'] != 'create'): ?>
              <input type="hidden" name="image_lama" value="<?php echo e($data['dosen']['foto']); ?>">
              <?php endif; ?>
              <?php $__errorArgs = ['cover'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Tipe Pegawai</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['tipe_pegawai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tipe_pegawai" name="tipe_pegawai" value="<?php echo e($data['type'] == 'create' ? old('tipe_pegawai') : old('tipe_pegawai', $data['dosen']['tipe_pegawai'])); ?>" placeholder="enter tipe_pegawai...">
              <?php $__errorArgs = ['tipe_pegawai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">No Kartu</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['no_kartu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="no_kartu" name="no_kartu" value="<?php echo e($data['type'] == 'create' ? old('no_kartu') : old('no_kartu', $data['dosen']['no_kartu'])); ?>" placeholder="enter no_kartu...">
              <?php $__errorArgs = ['no_kartu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">No WA</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['no_wa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="no_wa" name="no_wa" value="<?php echo e($data['type'] == 'create' ? old('no_wa') : old('no_wa', $data['dosen']['no_wa'])); ?>" placeholder="enter no_wa...">
              <?php $__errorArgs = ['no_wa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

        

         


          <div class="form-group row">
                <label class="col-form-label col-sm-2 text-sm-left">Alamat</label>
                <div class="col-sm-10">
                    <textarea class="form-control summernote" name="alamat"><?php echo $data['type'] == 'create' ? old('alamat') : old('alamat', $data['dosen']['alamat']); ?></textarea>
                </div>
            </div>


            <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Tempat Lahir</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tempat_lahir" name="tempat_lahir" value="<?php echo e($data['type'] == 'create' ? old('tempat_lahir') : old('tempat_lahir', $data['dosen']['tempat_lahir'])); ?>" placeholder="enter tempat_lahir...">
              <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Tanggal Lahir</label>
            <div class="col-sm-10">
              <input type="date" class="form-control <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tanggal_lahir" name="tanggal_lahir" value="<?php echo e($data['type'] == 'create' ? old('tanggal_lahir') : old('tanggal_lahir', $data['dosen']['tanggal_lahir'])); ?>" placeholder="enter tanggal_lahir...">
              <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Jenis Kelamin</label>
            <div class="col-sm-10">
            <select class="form-control selectpicker show-tick <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jenis_kelamin" data-style="btn-default">      
                    
                <option value="L" <?php echo e($data['type'] == 'create' ? old('jenis_kelamin')   : old('jenis_kelamin', $data['dosen']['jenis_kelamin']) == "L" ? 'selected' : ''); ?>> Laki-Laki</option>
                <option value="P" <?php echo e($data['type'] == 'create' ? old('jenis_kelamin')   : old('jenis_kelamin', $data['dosen']['jenis_kelamin']) == "P" ? 'selected' : ''); ?>> Perempuan</option>
            </select>  
                    
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Agama</label>
            <div class="col-sm-10">
            <select class="form-control selectpicker show-tick <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="agama" data-style="btn-default">      
                <option value="Islam" <?php echo e($data['type'] == 'create' ? old('agama')   : old('agama', $data['dosen']['agama']) == "Islam" ? 'selected' : ''); ?>> Islam</option>
                <option value="Kristen" <?php echo e($data['type'] == 'create' ? old('agama')   : old('agama', $data['dosen']['agama']) == "Kristen" ? 'selected' : ''); ?>> Kristen</option>
                <option value="Katolik" <?php echo e($data['type'] == 'create' ? old('agama')   : old('agama', $data['dosen']['agama']) == "Katolik" ? 'selected' : ''); ?>> Katolik</option>
                <option value="Hindu" <?php echo e($data['type'] == 'create' ? old('agama')   : old('agama', $data['dosen']['agama']) == "Hindu" ? 'selected' : ''); ?>> Hindu</option>
                <option value="Buddha" <?php echo e($data['type'] == 'create' ? old('agama')   : old('agama', $data['dosen']['agama']) == "Buddha" ? 'selected' : ''); ?>> Buddha</option>
                <option value="Konghucu" <?php echo e($data['type'] == 'create' ? old('agama')   : old('agama', $data['dosen']['agama']) == "Konghucu" ? 'selected' : ''); ?>> Konghucu</option>
            </select>  
                    
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Status Nikah</label>
            <div class="col-sm-10">
            <select class="form-control selectpicker show-tick <?php $__errorArgs = ['status_nikah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="status_nikah" data-style="btn-default">
                <option value="SM" <?php echo e($data['type'] == 'create' ? old('status_nikah')   : old('status_nikah', $data['dosen']['status_nikah']) == "SM" ? 'selected' : ''); ?>> Sudah Menikah</option>
                <option value="BM" <?php echo e($data['type'] == 'create' ? old('status_nikah')   : old('status_nikah', $data['dosen']['status_nikah']) == "BM" ? 'selected' : ''); ?>> Belum Menikah</option>
            </select>  
            </div>
          </div>

         



       

          <div class="form-group row">
            <div class="col-sm-10 ml-sm-auto">
              <button type="submit" class="btn btn-primary"><?php echo e($data['type'] == 'create' ? 'Simpan' : 'Simpan Perubahan'); ?></button>
              
            </div>
          </div>
        </form>
      </div>
    </div>

</div>
<!-- / Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsfoot'); ?>

 
<script src="<?php echo e(asset('asset/temp_backend/js/admin.js')); ?>"></script>

<script src="<?php echo e(asset('asset/temp_backend/libs/admin-resources/bootstrap-filestyle/bootstrap-filestyle.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/libs/bootstrap-maxlength/bootstrap-maxlength.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/js/pages/form-advanced.init.js')); ?>"></script>


<script src="<?php echo e(asset('asset/temp_backend/libs/tinymce/tinymce.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/libs/summernote/summernote-bs4.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/js/pages/form-editor.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nurul-ilmi\resources\views\backend\guru\form.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', $data['title']); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('asset/temp_backend/libs/summernote/summernote-bs4.min.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content -->
<div class="container-fluid flex-grow-1 container-p-y">

    <h4 class="font-weight-bold py-3 mb-4">
      <span class="text-muted font-weight-light">Siswa  /</span> Edit <span class="text-muted"></span>
    </h4>

    <div class="card mb-4">
      <h6 class="card-header">
        <i class="fas fa-plus"></i> Edit Siswa 
      </h6>
      <div class="card-body">
      
      <form enctype="multipart/form-data" action="<?php echo e(route('siswa.update', ['id' => $data['siswa']['id']])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
          
            
          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">No Induk</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['no_induk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($data['siswa']['no_induk']); ?>" id="no_induk" name="no_induk" required>
             
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">NISN</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['nisn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($data['siswa']['nisn']); ?>" id="nisn" name="nisn" required>
             
            </div>
          </div>
        
          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Nama</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($data['siswa']['nama']); ?>" id="nama" name="nama" required>
             
            </div>
          </div>

          
          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Jenis Kelamin</label>
            <div class="col-sm-10">
            <select required class="form-control selectpicker show-tick <?php $__errorArgs = ['jk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jk" data-style="btn-default">      
                <option value="L" <?php echo e($data['siswa']['jk'] == "L" ? 'selected' : ''); ?>> Laki-Laki</option>
                <option value="P" <?php echo e($data['siswa']['jk'] == "P" ? 'selected' : ''); ?>> Perempuan</option>
            </select>  
                    
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Foto</label>
            <div class="col-sm-10">
              <input type="file" class="form-control filestyle <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="foto" name="foto">
              <input type="hidden" name="foto_dulu" value="<?php echo e($data['siswa']['foto']); ?>">
              
            </div>
          </div>



          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Tempat Lahir</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($data['siswa']['tempat_lahir']); ?>" required id="tempat_lahir" name="tempat_lahir">
             
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Tanggal Lahir</label>
            <div class="col-sm-10">
              <input type="date" class="form-control <?php $__errorArgs = ['tgl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="tgl_lahir" value="<?php echo e($data['siswa']['tgl_lahir']); ?>" name="tgl_lahir">
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Umur</label>
            <div class="col-sm-10">
              <input type="text" value="<?php echo e($data['siswa']['umur']); ?>" class="form-control <?php $__errorArgs = ['umur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="umur" name="umur" required>
             
            </div>
          </div>


          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Agama</label>
            <div class="col-sm-10">
            <select required class="form-control selectpicker show-tick <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="agama" data-style="btn-default">      
            <option value="Islam" <?php echo e($data['siswa']['agama'] == "Islam" ? 'selected' : ''); ?>> Islam</option>
                <option value="Kristen" <?php echo e($data['siswa']['agama'] == "Kristen" ? 'selected' : ''); ?>> Kristen</option>
                <option value="Katolik" <?php echo e($data['siswa']['agama'] == "Katolik" ? 'selected' : ''); ?>> Katolik</option>
                <option value="Hindu" <?php echo e($data['siswa']['agama'] == "Hindu" ? 'selected' : ''); ?>> Hindu</option>
                <option value="Buddha" <?php echo e($data['siswa']['agama'] == "Buddha" ? 'selected' : ''); ?>> Buddha</option>
                <option value="Konghucu" <?php echo e($data['siswa']['agama'] == "Konghucu" ? 'selected' : ''); ?>> Konghucu</option>
            </select>  
                    
            </div>
          </div>

         <div class="form-group row">
                <label class="col-form-label col-sm-2 text-sm-left">Alamat</label>
                <div class="col-sm-10">
                    <textarea class="form-control" name="alamat"><?php echo e($data['siswa']['alamat']); ?></textarea>
                </div>
         </div> 


         <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Nama Ortu</label>
            <div class="col-sm-10">
              <input type="text"  value="<?php echo e($data['siswa']['nama_ortu']); ?>" class="form-control <?php $__errorArgs = ['nama_ortu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_ortu" name="nama_ortu" required>
             
            </div>
          </div>


          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Pendidikan Ortu</label>
            <div class="col-sm-10">
            <select required class="form-control selectpicker show-tick <?php $__errorArgs = ['pendidikan_ortu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pendidikan_ortu" data-style="btn-default">      
                <option value="SMP" <?php echo e($data['siswa']['pendidikan_ortu'] == "SMP" ? 'selected' : ''); ?>> SMP</option>
                <option value="SMA" <?php echo e($data['siswa']['pendidikan_ortu'] == "SMA" ? 'selected' : ''); ?>> SMA / Sederajat</option>
                <option value="D3" <?php echo e($data['siswa']['pendidikan_ortu'] == "D4" ? 'selected' : ''); ?>> D3</option>
                <option value="D4" <?php echo e($data['siswa']['pendidikan_ortu'] == "D4" ? 'selected' : ''); ?>> D4</option>
                <option value="S1" <?php echo e($data['siswa']['pendidikan_ortu'] == "S1" ? 'selected' : ''); ?>> S1</option>
                <option value="S2" <?php echo e($data['siswa']['pendidikan_ortu'] == "S2" ? 'selected' : ''); ?>> S2</option>
                <option value="S3" <?php echo e($data['siswa']['pendidikan_ortu'] == "S3" ? 'selected' : ''); ?>> S3</option>
            </select>  
                    
            </div>
          </div>


          <div class="form-group row">
                <label class="col-form-label col-sm-2 text-sm-left">Alamat Ortu</label>
                <div class="col-sm-10">
                    <textarea class="form-control" name="alamat_ortu" required><?php echo e($data['siswa']['alamat_ortu']); ?></textarea>
                </div>
         </div> 


         <div class="form-group row">
                <label class="col-form-label col-sm-2 text-sm-left">Keterangan</label>
                <div class="col-sm-10">
                    <textarea class="form-control summernote" name="keterangan"><?php echo e($data['siswa']['keterangan']); ?></textarea>
                </div>
         </div> 



       

          <div class="form-group row">
            <div class="col-sm-10 ml-sm-auto">
              <button type="submit" class="btn btn-primary">Simpan</button>
              
            </div>
          </div>
        </form>
      </div>
    </div>

</div>
<!-- / Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsfoot'); ?>

 
<script src="<?php echo e(asset('asset/temp_backend/js/admin.js')); ?>"></script>

<script src="<?php echo e(asset('asset/temp_backend/libs/admin-resources/bootstrap-filestyle/bootstrap-filestyle.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/libs/bootstrap-maxlength/bootstrap-maxlength.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/js/pages/form-advanced.init.js')); ?>"></script>


<script src="<?php echo e(asset('asset/temp_backend/libs/tinymce/tinymce.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/libs/summernote/summernote-bs4.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/js/pages/form-editor.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nurul-ilmi\resources\views\backend\siswa\edit.blade.php ENDPATH**/ ?>
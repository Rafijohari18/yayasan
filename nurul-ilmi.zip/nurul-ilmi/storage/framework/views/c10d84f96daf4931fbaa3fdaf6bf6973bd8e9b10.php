

<?php $__env->startSection('title', $data['title']); ?>

<?php $__env->startSection('content'); ?>
<!-- Content -->

<div class="container-fluid flex-grow-1 container-p-y">
    <?php if(session('error')): ?>
    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>
  

  <h4 class="font-weight-bold py-3 mb-4">
    <span class="text-muted font-weight-light">Pengaturan Akun /</span> <?php echo e(Auth::user()['name']); ?> 
  </h4>

  <div class="card overflow-hidden">
    <div class="row no-gutters row-bordered row-border-light">
      <div class="col-md-3 pt-0">
        <div class="list-group list-group-flush account-settings-links">
          <a class="list-group-item list-group-item-action active" data-toggle="list" href="#account-general">Umum</a>
          <a class="list-group-item list-group-item-action" data-toggle="list" href="#account-change-password">Ganti Kata Sandi</a>
          <?php if(Auth::user()['level'] == 5 || Auth::user()['level'] == 6): ?>
          <a class="list-group-item list-group-item-action" data-toggle="list" href="#alamat">Alamat</a>
          <?php endif; ?>
        </div>
      </div>
      <div class="col-md-9">
        <form action="<?php echo e(route('users.update-profile', ['id' => Auth::user()['id']])); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
        <div class="tab-content">
          <div class="tab-pane fade show active" id="account-general">
          
            <div class="card-body media align-items-center">
              <?php if(Auth::user()['avatar'] != null): ?>
                <img src="<?php echo e(asset('userfile/photo/'.Auth::user()['avatar'])); ?>" alt class="d-block ui-w-80"> 
              <?php else: ?>
              <img src="<?php echo e(asset('assets/temp_backend/img/avatars/1.png')); ?>"" alt class="d-block ui-w-80">
              <?php endif; ?>
              <!-- <div class="media-body ml-4 mb-1">
                <label class="btn btn-outline-primary mb-2" data-toggle="modal" data-target="#modals-default">
                  Ganti Foto Profil
                </label> &nbsp;
                <?php if(Auth::user()['avatar'] != null): ?>
                <a href="javascript:void(0);" class="btn btn-outline-danger md-btn-flat delete"> Hapus
                <form action="<?php echo e(route('users.remove-photo', ['id' => Auth::user()['id']])); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PUT'); ?>                                            
                </form>
                </a>
                <?php endif; ?>
                <div class="text-light small mt-1">Type File( <?php echo e(strtoupper(Config::get('addon.validation_upload.format_photo'))); ?>), <?php echo e(Config::get('addon.validation_upload.pixel_photo_profile')); ?>. Max. ukuran file <?php echo e(Config::get('addon.validation_upload.upload_size')); ?></div>
              </div> -->
            </div>
            <hr class="border-light m-0">
            </form>
            
           
            <form action="<?php echo e(route('users.update-profile', ['id' => Auth::user()['id']])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="card-body">
             
              <div class="form-group">
                <label class="form-label">NIP</label>
                <input type="text" class="form-control mb-1 <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nip" value="<?php echo e(old('nip', Auth::user()->Petugas['nip'])); ?>" placeholder="your nip..." readonly>
                <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="invalid-feedback"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group">
                <label class="form-label">Nama Lengkap</label>
                <input type="text" class="form-control mb-1 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name', Auth::user()['name'])); ?>" placeholder="your name...">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="invalid-feedback"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            
              <div class="form-group">
                <label class="form-label">E-mail</label>
                <input type="email" class="form-control mb-1 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email', Auth::user()['email'])); ?>" placeholder="your email..." readonly>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="invalid-feedback"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              
              </div>
              

              <div class="form-group">
                <label class="form-label">No Handphone</label>
                <input type="text" class="form-control mb-1 <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" no_hp="no_hp" value="<?php echo e(old('no_hp', Auth::user()->Petugas['no_hp'])); ?>" placeholder="your no handphone...">
                <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="invalid-feedback"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group">
                <label class="form-label">Alamat</label>
                <textarea  class="form-control mb-1 <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="alamat" placeholder="your address..."><?php echo e(old('alamat', Auth::user()->Petugas['alamat'])); ?></textarea>
                <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="invalid-feedback"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

            </div>

          </div>

          <div class="tab-pane fade" id="account-change-password">
            <div class="card-body pb-2">

              <div class="form-group">
                <label class="form-label">Kata Sandi Baru</label>
                <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" placeholder="your password...">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="invalid-feedback"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group">
                <label class="form-label">Ulangi Kata Sandi Baru</label>
                <input type="password" class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password_confirmation" placeholder="your password confirmation...">
                <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="invalid-feedback"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

            </div>
          </div>
        </div>
        <div class="d-flex justify-content-center">
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
        <br>
      
      </div>
      </form>
 
    
   

   
    
    </div>
  </div>


</div>
<!-- / Content -->

<div class="modal fade" id="modals-default">
  <div class="modal-dialog">
      <form class="modal-content" action="<?php echo e(route('users.change-photo', ['id' => Auth::user()['id']])); ?>" method="post" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
      <div class="modal-header">
          <h5 class="modal-title">
          Change Your
          <span class="font-weight-light">Photo</span>
          </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">×</button>
      </div>
      <div class="modal-body">
          <div class="form-row">
          <div class="form-group col">
              <label class="form-label">Browse Photo :</label><br>
              <input type="hidden" name="oldphoto" value="<?php echo e(Auth::user()['avatar']); ?>">
              <input type="file" name="photo" required>
          </div>
          </div>
      </div>
      <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
      </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/temp_backend/vendor/css/pages/account.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsbody'); ?>
<script src="<?php echo e(asset('assets/temp_backend/js/ui_modals.js')); ?>"></script>
<script>
    $('.delete').click(function(e)
    {
        e.preventDefault();
        var url = $(this).attr('href');
        Swal.fire({
        title: 'Apa anda yakin ingin menghapus foto profil ?',
        text: "",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, remove it!'
        }).then((result) => {
        if (result.value) {
            $(this).find('form').submit();
        }
        })
    });
    
   
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nurul-ilmi\resources\views\backend\users\profile.blade.php ENDPATH**/ ?>
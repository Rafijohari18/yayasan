
<?php $__env->startSection('title','Home - Yayasan Nurul Ilmi'); ?>
<?php $__env->startSection('css'); ?>
<style>
@media  only screen and (min-width: 768px) {
	#lable-sekolah{
		margin-left:20px;
		left:10%;
	}
	.card-title{
  		-ms-transform: translateY(100%);
  		transform: translateY(100%);
	}
	#logo-yayasan{
		width:60px;
		heigth:auto;
		border-radius:100%;
		-ms-transform: translateY(50%);
		transform: translateY(50%);

	}
}

@media  only screen
and (min-device-width : 320px)
and (max-device-width : 568px) {
	#logo-yayasan{
		width:50px;
		heigth:auto;
		border-radius:100%;
		-ms-transform: translateY(50%);
		transform: translateY(50%);
	}
	.card-title{
  		-ms-transform: translateX(40%);
  		transform: translateX(40%);
		margin-top:-10px;
	}
	#lable-sekolah{
		margin-top:15px;
	}
}

#lable-sekolah{
	border-top-left-radius: 15px 15px;
	border-bottom-right-radius: 15px 15px;
	height:80px;
}

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<aside id="colorlib-hero">
	<div class="flexslider">
		<ul class="slides">
			<?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li style="background-image: url(<?php echo e(asset($slid->image)); ?>);">
					<div class="overlay"></div>
					<div class="container-fluid">
						<div class="row">
							<div class="col-md-8 col-sm-12 col-md-offset-2 col-xs-12 col-md-pull-1 slider-text">
								<div class="slider-text-inner">
									<div class="desc">
										<h2><?php echo e($slid->title); ?></h2>
										<h1><?php echo e(strip_tags($slid->content)); ?></h1>
										
									</div>
								</div>
							</div>
						</div>
					</div>
				</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		</ul>
	</div>
</aside>
<div class="colorlib-search">
	<div class="container">
		<div class="row">
			<div class="col-md-12 search-wrap">
				<div class="search-wrap-2">
	
					<div class="row justify-content-center align-items-center">
						<?php $__currentLoopData = $sekolah_yayasan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sekyayasan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<a href="<?php echo e(strip_tags($sekyayasan->content)); ?>">
						<div class="col-md-3 bg-primary mb-3" id="lable-sekolah"> 
							<div class="card">
								
								<div class="col-md-4">
									<img src="<?php echo e(asset($sekyayasan->cover)); ?>" alt="logo-sd" id="logo-yayasan">
								</div>
								<div class="col-md-8 ">
									<h4 class="card-title"><?php echo e($sekyayasan->title); ?></h4>

								</div>
									
							</div>
						</div>
						</a>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
					
						
					</div>
					
				
			</div>
		</div>
	</div>



</div>

<div id="colorlib-counter" class="colorlib-counters">
			<div class="container">
				<div class="row">
					<div class="col-md-7">
						<div class="about-desc">
                            <?php $__currentLoopData = $foto_ketua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="about-img-<?php echo e($key + 1); ?> animate-box" style="background-image: url(<?php echo e(asset($foto->file)); ?>);"></div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
					<div class="col-md-5">
						<div class="row">
							<div class="col-md-12 colorlib-heading animate-box">
								<h1 class="heading-big"><?php echo e($sambutan->title); ?></h1>
								<h2><?php echo e($sambutan->title); ?> </h2>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12 animate-box">
								<?php echo $sambutan->content; ?>

							</div>
						
						</div>
					</div>
				</div>
			</div>
		</div>

<div class="colorlib-classes">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 colorlib-heading center-heading text-center animate-box">
				<h1 class="heading-big">Artikel & Berita Terbaru</h1>
				<h2>Artikel & Berita Terbaru</h2>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12 animate-box">
				<div class="owl-carousel">
					<?php $__currentLoopData = $berita_terbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="item">
						<div class="classes">
							<div class="classes-img" style="background-image: url(<?php echo e(asset($berita->cover)); ?>);">
							</div>
							<div class="wrap">
								<div class="desc">
									<span class="teacher"><?php echo e($berita->user->name); ?></span>
									<h3><a href="#"><?php echo e($berita->title); ?></a></h3>
								</div>
								<div class="pricing">
									<p><a href="<?php echo e(route('berita.detail',['slug' => $berita->slug])); ?>" class="btn btn-primary">Baca Selengkapnya</a> <span class="more"><a href="#"><i class="icon-link"></i></a></span></p>
								</div>
							</div>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</div>
	</div>
</div>



<?php $__env->stopSection(); ?>

	
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nurul-ilmi\resources\views\frontend\index.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', $data['title']); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('asset/temp_backend/libs/summernote/summernote-bs4.min.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content -->
<div class="container-fluid flex-grow-1 container-p-y">

    <h4 class="font-weight-bold py-3 mb-4">
      <span class="text-muted font-weight-light">Guru  /</span> Edit <span class="text-muted"></span>
    </h4>

    <div class="card mb-4">
      <h6 class="card-header">
        <i class="fas fa-plus"></i> Edit Guru 
      </h6>
      <div class="card-body">
        <form enctype="multipart/form-data" action="<?php echo e(route('guru.update', ['id' => $data['guru']['id']])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
          
        
          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Nama</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($data['guru']['nama']); ?>" id="nama" name="nama" required>
             
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Foto</label>
            <div class="col-sm-10">
              <input type="file" class="form-control filestyle <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="foto" name="foto">
              <input type="hidden" name="foto_dulu" value="<?php echo e($data['guru']['foto']); ?>">

            </div>
          </div>



          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Tempat Lahir</label>
            <div class="col-sm-10">
              <input type="text" value="<?php echo e($data['guru']['tempat_lahir']); ?>"  class="form-control <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="tempat_lahir" name="tempat_lahir">
             
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Tanggal Lahir</label>
            <div class="col-sm-10">
              <input type="date" value="<?php echo e($data['guru']['tgl_lahir']); ?>" class="form-control <?php $__errorArgs = ['tgl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required id="tgl_lahir" name="tgl_lahir">
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Pendidikan</label>
            <div class="col-sm-10">
            <select required class="form-control selectpicker show-tick <?php $__errorArgs = ['pendidikan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pendidikan" data-style="btn-default">      
                <option value="SMP" <?php echo e($data['guru']['pendidikan'] == "SMP" ? 'selected' : ''); ?>> SMP</option>
                <option value="SMA" <?php echo e($data['guru']['pendidikan'] == "SMA" ? 'selected' : ''); ?>> SMA / Sederajat</option>
                <option value="D3" <?php echo e($data['guru']['pendidikan'] == "D4" ? 'selected' : ''); ?>> D3</option>
                <option value="D4" <?php echo e($data['guru']['pendidikan'] == "D4" ? 'selected' : ''); ?>> D4</option>
                <option value="S1" <?php echo e($data['guru']['pendidikan'] == "S1" ? 'selected' : ''); ?>> S1</option>
                <option value="S2" <?php echo e($data['guru']['pendidikan'] == "S2" ? 'selected' : ''); ?>> S2</option>
                <option value="S3" <?php echo e($data['guru']['pendidikan'] == "S3" ? 'selected' : ''); ?>> S3</option>
            </select>  
                    
            </div>
          </div>


          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Jenis Kelamin</label>
            <div class="col-sm-10">
            <select required class="form-control selectpicker show-tick <?php $__errorArgs = ['jk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jk" data-style="btn-default">      
                <option value="L" <?php echo e($data['guru']['jk'] == "L" ? 'selected' : ''); ?>> Laki-Laki</option>
                <option value="P" <?php echo e($data['guru']['jk'] == "P" ? 'selected' : ''); ?>> Perempuan</option>
            </select>  
                    
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Agama</label>
            <div class="col-sm-10">
            <select required class="form-control selectpicker show-tick <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="agama" data-style="btn-default">      
                <option value="Islam" <?php echo e($data['guru']['agama'] == "Islam" ? 'selected' : ''); ?>> Islam</option>
                <option value="Kristen" <?php echo e($data['guru']['agama'] == "Kristen" ? 'selected' : ''); ?>> Kristen</option>
                <option value="Katolik" <?php echo e($data['guru']['agama'] == "Katolik" ? 'selected' : ''); ?>> Katolik</option>
                <option value="Hindu" <?php echo e($data['guru']['agama'] == "Hindu" ? 'selected' : ''); ?>> Hindu</option>
                <option value="Buddha" <?php echo e($data['guru']['agama'] == "Buddha" ? 'selected' : ''); ?>> Buddha</option>
                <option value="Konghucu" <?php echo e($data['guru']['agama'] == "Konghucu" ? 'selected' : ''); ?>> Konghucu</option>
            </select>  
                    
            </div>
          </div>


          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Pelatihan</label>
            <div class="col-sm-10">
            <?php if($data['guru']['pelatihan'] != null): ?>

            <?php for($i=0; $i < count( $data['guru']['pelatihan']) ; $i++): ?>
              <input type="text" class="form-control mb-3 <?php $__errorArgs = ['pelatihan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pelatihan" name="pelatihan[]" value="<?php echo e($data['guru']['pelatihan'][$i]); ?>">
            <?php endfor; ?>
            <?php else: ?>
              <input type="text" class="form-control mb-3 <?php $__errorArgs = ['pelatihan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pelatihan" name="pelatihan[]">
              <input type="text" class="form-control mb-3 <?php $__errorArgs = ['pelatihan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pelatihan" name="pelatihan[]">
              <input type="text" class="form-control mb-3 <?php $__errorArgs = ['pelatihan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pelatihan" name="pelatihan[]">
            <?php endif; ?>
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Prestasi</label>
            <div class="col-sm-10">
                
                
                <?php if($data['guru']['prestasi'] != null): ?>
                <?php for($a=0; $a < count($data['guru']['prestasi']) ; $a++): ?>
                    <input type="text" class="form-control mb-3 <?php $__errorArgs = ['prestasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="prestasi" name="prestasi[]" value="<?php echo e($data['guru']['prestasi'][$a]); ?>">
                <?php endfor; ?>

                <?php else: ?>
                    <input type="text" class="form-control mb-3 <?php $__errorArgs = ['prestasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="prestasi" name="prestasi[]">
                    <input type="text" class="form-control mb-3 <?php $__errorArgs = ['prestasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="prestasi" name="prestasi[]">
                    <input type="text" class="form-control mb-3 <?php $__errorArgs = ['prestasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="prestasi" name="prestasi[]">
                <?php endif; ?>
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Penghargaan</label>
            <div class="col-sm-10">
                <?php if($data['guru']['penghargaan'] != null): ?>

                <?php for($v=0; $v < count( $data['guru']['penghargaan']) ; $v++): ?>
                    <input type="text" class="form-control mb-3 <?php $__errorArgs = ['penghargaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="penghargaan" name="penghargaan[]" value="<?php echo e($data['guru']['penghargaan'][$v]); ?>">
                <?php endfor; ?>
                
                <?php else: ?>
                <input type="text" class="form-control mb-3 <?php $__errorArgs = ['penghargaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="penghargaan" name="penghargaan[]">
              <input type="text" class="form-control mb-3 <?php $__errorArgs = ['penghargaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="penghargaan" name="penghargaan[]">
              <input type="text" class="form-control mb-3 <?php $__errorArgs = ['penghargaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="penghargaan" name="penghargaan[]">
                <?php endif; ?>
            
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Jabatan</label>
            <div class="col-sm-10">
              <input type="text" value="<?php echo e($data['guru']['jabatan']); ?>" required class="form-control <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jabatan" name="jabatan">
             
            </div>
          </div>

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">Tahun Masuk</label>
            <div class="col-sm-10">
              <input type="date" value="<?php echo e($data['guru']['thn_masuk']); ?>" required class="form-control <?php $__errorArgs = ['thn_masuk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="thn_masuk" name="thn_masuk">
            </div>
          </div>

          <div class="form-group row">
                <label class="col-form-label col-sm-2 text-sm-left">Alamat</label>
                <div class="col-sm-10">
                    <textarea class="form-control summernote" name="alamat"><?php echo e($data['guru']['alamat']); ?></textarea>
                </div>
         </div> 

          <div class="form-group row">
            <label class="col-form-label col-sm-2 text-sm-left">TMT</label>
            <div class="col-sm-10">
              <input type="date" value="<?php echo e($data['guru']['tmt']); ?>" required class="form-control <?php $__errorArgs = ['tmt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tmt" name="tmt">
            </div>
          </div>


       

          <div class="form-group row">
            <div class="col-sm-10 ml-sm-auto">
              <button type="submit" class="btn btn-primary">Simpan</button>
              
            </div>
          </div>
        </form>
      </div>
    </div>

</div>
<!-- / Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsfoot'); ?>

 
<script src="<?php echo e(asset('asset/temp_backend/js/admin.js')); ?>"></script>

<script src="<?php echo e(asset('asset/temp_backend/libs/admin-resources/bootstrap-filestyle/bootstrap-filestyle.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/libs/bootstrap-maxlength/bootstrap-maxlength.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/js/pages/form-advanced.init.js')); ?>"></script>


<script src="<?php echo e(asset('asset/temp_backend/libs/tinymce/tinymce.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/libs/summernote/summernote-bs4.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/js/pages/form-editor.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nurul-ilmi\resources\views\backend\guru\edit.blade.php ENDPATH**/ ?>
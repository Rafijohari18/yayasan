

<?php $__env->startSection('title', $data['title']); ?>


<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('asset/temp_backend/libs/summernote/summernote-bs4.min.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('asset/temp_backend/libs/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('asset/temp_backend/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css')); ?>" rel="stylesheet" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content -->
<div class="container-fluid  container-p-y">

    <h4 class="font-weight-bold py-3 mb-4">
      <span class="text-muted font-weight-light">Pengaturan / </span><?php echo e($data['title']); ?>

    </h4>

    <div class="card">
      <h6 class="card-header">
        <i class="fas fa-edit"></i> Form Pengaturan
      </h6>
      <div class="card-body">
        <hr class="border-light m-0">
        <br>

         <div class="nav-tabs-top">
          <ul class="nav nav-tabs">
              <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#web">Web Config</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#sosmed">Sosial Media</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#logo">Logo Web</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#background">Background Web</a>
              </li>

              
            </ul>
            
            <div class="tab-content">

            <div class="tab-pane fade show active" id="web">
                <div class="card">
                    <div class="card-body">
                      <form action="<?php echo e(route('update.config')); ?>" method="POST" id="form_all">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('PUT'); ?>
                        <?php $__currentLoopData = $data['web']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $web): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
                          <div class="form-group row">
                            <label class="col-form-label col-sm-2 text-sm-left"><?php echo e($web['lable']); ?> </label>
                            <div class="col-sm-10">
                              <?php if($web['id'] != 9): ?>
                              <textarea type="text" class="form-control" name="name[<?php echo e($web['name']); ?>]"  placeholder="enter value..."><?php echo e(old($web['name'], $web['value'])); ?></textarea>
                              <?php else: ?> 
                              <div class="input-group colorpicker-default" title="Using format option">
                                <input type="text" class="form-control input-lg" name="name[<?php echo e($web['name']); ?>]" value="<?php echo e(old($web['name'], $web['value'])); ?>"/>
                                <span class="input-group-append">
                                    <span class="input-group-text colorpicker-input-addon"><i></i></span>
                                </span>
                              </div>
                              <?php endif; ?>
                            </div>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      

                          <div class="form-group row mt-2">
                          <div class="col-sm-10 ml-sm-auto">
                            <button id="btn-sub" type="submit" class="btn btn-primary pull-right">Simpan </button>
                          </div>
                        </div>
                        </form>


                    </div>
                </div>
            </div>



            <div class="tab-pane fade" id="sosmed"            >
                <div class="card">
                    <div class="card-body">
                     <form action="<?php echo e(route('update.config')); ?>" method="POST" id="form_sosmed">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('PUT'); ?>
                        <?php $__currentLoopData = $data['sosmed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sosmed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          <div class="form-group row">
                            <label class="col-form-label col-sm-2 text-sm-left"><?php echo e($sosmed['lable']); ?> </label>
                            <div class="col-sm-10">
                              <textarea type="text" class="form-control" name="name[<?php echo e($sosmed['name']); ?>]" placeholder="enter value..."><?php echo e(old($sosmed['name'], $sosmed['value'])); ?></textarea>
                            </div>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          <div class="form-group row mt-2">
                          <div class="col-sm-10 ml-sm-auto">
                            <button id="btn-sosmed" type="submit" class="btn btn-primary pull-right">Simpan </button>
                          </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="logo">
                <div class="card">
                    <div class="card-body">
                     <form action="<?php echo e(route('update.config.logo')); ?>" method="POST" enctype="multipart/form-data" id="form_background">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('PUT'); ?>
                        <?php $__currentLoopData = $data['logo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $web): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          <div class="form-group row">
                            <label class="col-form-label col-sm-2 text-sm-left"><?php echo e($web['lable']); ?> </label>
                            
                            <div class="col-sm-10">
                            <img src="<?php echo e(asset($web['value'])); ?>" alt="IMAGES" class="mb-4" style="width:250px;height:auto;" id="previewimg">

                            
                            <input type="file" class="form-control filestyle file" name="logo" >

                            <input type="hidden" name="logo_lama" value="<?php echo e($web['value']); ?>">
                              
                            </div>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          <div class="form-group row mt-2">
                          <div class="col-sm-10 ml-sm-auto">
                            <button id="btn-background" type="submit" class="btn btn-primary pull-right">Simpan </button>
                          </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>


            <div class="tab-pane fade" id="background">
                <div class="card">
                    <div class="card-body">
                     <form action="<?php echo e(route('update.config.background')); ?>" method="POST" enctype="multipart/form-data" id="form_background">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('PUT'); ?>
                        <?php $__currentLoopData = $data['background']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $web): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          <div class="form-group row">
                            <label class="col-form-label col-sm-2 text-sm-left"><?php echo e($web['lable']); ?> </label>
                            
                            <div class="col-sm-10">
                            <img src="<?php echo e(asset($web['value'])); ?>" alt="IMAGES" class="mb-4" style="width:250px;height:auto;" id="previewimg">

                            
                            <input type="file" class="form-control filestyle file" name="background" >

                            <input type="hidden" name="background_lama" value="<?php echo e($web['value']); ?>">
                              
                            </div>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          <div class="form-group row mt-2">
                          <div class="col-sm-10 ml-sm-auto">
                            <button id="btn-background" type="submit" class="btn btn-primary pull-right">Simpan </button>
                          </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>






          </div>
        </div>



       </div>
    </div>

</div>
<!-- / Content -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('jsfoot'); ?>
<script src="<?php echo e(asset('asset/temp_backend/libs/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js')); ?>"></script>
        
<script src="<?php echo e(asset('asset/temp_backend/libs/admin-resources/bootstrap-filestyle/bootstrap-filestyle.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/libs/bootstrap-maxlength/bootstrap-maxlength.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/temp_backend/js/pages/form-advanced.init.js')); ?>"></script>


<script>
  $('.delete').click(function(e)
      {
        e.preventDefault();
        var url = $(this).attr('href');
        Swal.fire({
          title: 'Hapus Config Penyakit ?',
          text: "Apakah anda yakin!",
          type: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Ya !'
        }).then((result) => {
          if (result.value) {
            $(this).find('form').submit();
          }
        })
      });


      $('#btn-sub').click(function() {
          $('#form_all').submit();
      });

      $('#btn-sosmed').click(function() {
          $('#form_sosmed').submit();
      });

      $('#btn-background').click(function() {
          $('#form_background').submit();
      });

      function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#previewimg').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
      }


      $('.file').change(function(){
        readURL(this);
      });


</script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nurul-ilmi\resources\views/backend/config/web-config.blade.php ENDPATH**/ ?>